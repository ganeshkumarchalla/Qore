QORE Desktop for Windows
========================

1. Extract all files from this archive.
2. Double-click QORE-Setup.exe to run the interactive installation wizard.
   (Or run: QORE-Setup.exe /SILENT /DIR="%LOCALAPPDATA%\Programs\QORE")
3. Launch QORE Desktop from the Desktop shortcut or QORE-Desktop.exe.
